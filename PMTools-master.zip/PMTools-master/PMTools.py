import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
from templates.app import app

from templates.pages import (
    svg_to_pdf_converter,
    pmd_charts,
    pmm_dir_charts,
)
import webbrowser

server = app.server

tab_selected_style = {
    'borderTop': '1px solid #d6d6d6',
    'borderBottom': '1px solid #d6d6d6',
    'backgroundColor': '#119DFF',
    'color': 'white',
    'padding': '6px'
}

app.layout = html.Div(
    [
        html.Div(
            [
                html.Div(
                    className="row",
                    children=[
                        html.Div(
                            className='ten columns',
                            children=[
                                html.Img(
                                    className="logo",
                                    src=app.get_asset_url("pm-tools-icon.svg")
                                )
                            ]
                        ),
                        html.Div(
                            className='two columns',
                            children=[
                                # html.Button(
                                #     'About',
                                #     id='about',
                                # )
                                'Contacts: ',
                                html.A('I1948374@yandex.ru')
                            ]
                        )

                    ],
                ),
                html.Div(
                    className="tabs-container",
                    children=[
                        dcc.Tabs(id="tabs", value='pmd-charts', children=
                            [
                                dcc.Tab(
                                    label=".PMD",
                                    value='pmd-charts',
                                    className="tab",
                                    selected_style=tab_selected_style
                                ),
                                dcc.Tab(
                                    label=".DIR & .PMM",
                                    value='pmm-dir-charts',
                                    className="tab",
                                    selected_style=tab_selected_style
                                ),
                                dcc.Tab(
                                    label=".SVG to .PDF",
                                    value='svg-to-pdf-converter',
                                    className="tab",
                                    selected_style=tab_selected_style
                                ),
                            ]
                        ),
                    ]
                )
            ]
        ),

        html.Div(
            id="tab_content",
            className="page"
        ),
    ],
)

# Update the index


@app.callback(
    Output("tab_content", "children"),
    [Input("tabs", "value")],
)
def display_tab_content(tab):
    if tab == "pmd-charts":
        return pmd_charts.layout
    if tab == "pmm-dir-charts":
        return pmm_dir_charts.layout
    if tab == "svg-to-pdf-converter":
        return svg_to_pdf_converter.layout

webbrowser.open("http://127.0.0.1:8052", new=2)

if __name__ == "__main__":
    app.run_server(debug=False, port=8052)

webbrowser.get("http://127.0.0.1:8050")
