import dash
from flask import Flask

external_stylesheets = ['templates/bWLwgP.css']

server = Flask(__name__)
app = dash.Dash(server=server, external_stylesheets=external_stylesheets)

app.config['suppress_callback_exceptions']=True
