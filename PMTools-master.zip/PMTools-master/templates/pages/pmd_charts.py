# -*- coding: utf-8 -*-
import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_daq as daq
import dash_table
import urllib
from urllib import parse

import plotly.graph_objs as go

import pandas as pd

import base64
import io, os, time
import numpy as np

import cairosvg
import glob

from pathlib import Path
from sklearn.decomposition import PCA
from plotly.subplots import make_subplots
from templates.app import app, server
from flask import send_from_directory


open("mag_annotations.txt", "w").close()

dff = pd.DataFrame(
                {'T or M': [], 'X': [], 'Y': [], 'Z': [], 'MAG': [],
                 'Dg': [], 'Ig': [], 'Ds': [], 'Is': [], 'a95': []}
)


def column_cleaner(string):
    while len(string) and not (string[0] >= "0" and string[0] <= "9"):
        string = string[1:]
    return string


def transform_data(raw_table):
    tmp_data = raw_table
    tmp_data.to_csv("TMP")
    data = pd.read_csv("TMP", header=None)

    # delete all before "PAL"

    i = 0
    while True:
        if data.iloc[i][1][:4] == " PAL" or data.iloc[i][1][:4] == "PAL ":
            break
        i += 1
    # additional data, non-table format

    extra_data = data.iloc[i - 1][1].split('   ')
    # code_name = extra_data[0]
    A = float(extra_data[1].split('=')[1])
    B = float(extra_data[2].split('=')[1])
    S = float(extra_data[3].split('=')[1])
    D = float(extra_data[4].split('=')[1])
    # v = extra_data[5]
    extra_data = [A, B, S, D]
    # delete extra_data from data
    a = []
    for j in range(i + 1):
        a.append(j)
    data.drop(a, axis=0, inplace=True)

    # create DataFrame

    tmp_tb = []
    for i in data[1]:
        tmp_tb.append(i.split())
    data = pd.DataFrame(tmp_tb)

    # checking first col for bad data like "T 20" instead of "T20"

    for i in range(0, len(data), 1):
        if data[0][i].isalpha() and data[len(data.columns) - 1][i] != None:
            for j in range(0, len(data.columns) - 1, 1):
                data[j][i] += data[j + 1][i]
                data[j + 1][i] = ''

    # cleaning DataFrame from extra columns

    if len(data.columns) > 10:
        for i in range(10, len(data.columns), 1):
            data.drop(data.columns[[i]], axis='columns', inplace=True)

    # cleaning DataFrame from bad rows with unresolved symbols

    if not data[0][len(data) - 1].isalnum():
        data.drop(len(data) - 1, axis=0, inplace=True)

    # cleaning first column from symbols and create first_col_measure for name this column

    first_col = data[0]
    first_col_measure = "T"
    if data[0][0][0] == "M":
        first_col_measure = "M"
    data[0] = list(map(column_cleaner, first_col))

    # renaming DataFrame columns

    data.rename(
        columns={0: first_col_measure,
                 1: "X",
                 2: "Y",
                 3: "Z",
                 4: "MAG",
                 5: "Dg",
                 6: "Ig",
                 7: "Ds",
                 8: "Is",
                 9: "a95"},
        inplace=True
    )

    # data to numeric format

    for i in data.columns:
        data[i] = pd.to_numeric(data[i])

    data['X'] = data['X'].map('{:,.2E}'.format)
    data['Y'] = data['Y'].map('{:,.2E}'.format)
    data['Z'] = data['Z'].map('{:,.2E}'.format)
    data['MAG'] = data['MAG'].map('{:,.2E}'.format)

    # return data

    return data, first_col_measure, extra_data


def parse_contents_for_plot_dt(contents, filename, for_what):
    content_type, content_string = contents.split(',')

    decoded = base64.b64decode(content_string)
    raw_df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))

    df, first_col_name, extra_data = transform_data(raw_df)
    print(df.to_dict('records'))
    if for_what == "for_table":
        return html.Div(
            className="pretty-table",
            children=[
                html.Div(
                    dcc.Markdown(
                        "**a** = " + str(extra_data[0]) + ";"
                        " **b** = " + str(extra_data[1]) + ";"
                        " **s** = " + str(extra_data[2]) + ";"
                        " **d** = " + str(extra_data[3])
                    )
                ),
                html.Div(
                    dash_table.DataTable(
                        id='data-pmd',
                        data=df.to_dict('records'),
                        columns=[{'name': i, 'id': i} for i in df.columns],
                        style_header={
                            'backgroundColor': '#F5FFFA',
                            'fontWeight': 'bold',
                        },
                        style_table={
                            'maxHeight': '300px',
                            'overflowY': 'scroll',
                        }
                    ),
                )
            ]
        )
    if for_what == "for_extra_data":
        return extra_data


def create_dots_list(data, droplist_name):
    df = pd.DataFrame(data)
    labels = list()

    unit = u"\u00B0"
    first_col_name = 'T'

    if 'M' in data[0]:
        first_col_name = 'M'
        unit = "mT"
    if droplist_name == "dots-with-annotation":
        for i in range(len(df[first_col_name])):
            labels.append(
                {
                    'label': str(int(df[first_col_name][i]))+unit,
                    'value': i
                }
            )
    if droplist_name == "dots-to-approx":
        for i, value in enumerate(df[first_col_name]):
            labels.append(
                {
                    'label':str(i+1)+": "+str(int(value))+unit,
                    'value':i
                }
            )

    return labels


def create_orthodromy(data_table, system):
    col_D = "Dg"
    col_I = "Ig"

    if system == "stratigraphic":
        col_D = "Ds"
        col_I = "Is"
    raw_longitudes = data_table[col_D]
    raw_latitudes = data_table[col_I]
    orthodromes_D = []
    orthodromes_I = []

    for i in range(len(data_table) - 1):

        start_longitude = np.radians(raw_longitudes[i])
        start_latitude = np.radians(raw_latitudes[i])
        end_longitude = np.radians(raw_longitudes[i + 1])
        end_latitude = np.radians(raw_latitudes[i + 1])

        reverse = False

        if start_longitude > end_longitude:
            start_longitude, end_longitude = end_longitude, start_longitude
            reverse = True

        if np.degrees(end_longitude) - np.degrees(start_longitude) > 180:
            reverse = not reverse
            start_longitude, end_longitude = end_longitude, start_longitude + 2 * np.pi

        orthodromy_D = []
        orthodromy_I = []

        for longitude in np.arange(start_longitude, end_longitude + abs(start_longitude - end_longitude) / 100,
                                   abs(start_longitude - end_longitude) / 100):
            longitude %= 2 * np.pi

            latitude = np.degrees(
                np.arctan(
                    ((np.tan(start_latitude) * np.sin(end_longitude - longitude)) /
                     (np.sin(end_longitude - start_longitude))) +
                    ((np.tan(end_latitude) * np.sin(longitude - start_longitude)) /
                     (np.sin(end_longitude - start_longitude)))
                )
            )

            longitude = np.degrees(longitude)

            orthodromy_D.append(longitude)
            orthodromy_I.append(abs(abs(latitude) - 90))

        if reverse:
            orthodromy_D = orthodromy_D[::-1]
        orthodromes_D.append(orthodromy_D)
        orthodromes_I.append(orthodromy_I)

    return (
        orthodromes_D, orthodromes_I
    )


def give_a95_k_rm(data, selected_dots, system, pca_mode):
    col_D = "Dg"
    col_I = "Ig"
    if system == "stratigraphic":
        col_D = "Ds"
        col_I = "Is"

    xs = 0
    ys = 0
    zs = 0
    a95 = 0  # the radius of the confidence circle
    Rs = 1  # average vector always has the length of 1 because all vectors have the same length of 1
    n = len(selected_dots)
    if pca_mode == 'zero-mode':
        n+=1
    for i in selected_dots:
        rI = np.radians(float(data[col_I][i]))
        rD = np.radians(float(data[col_D][i]))
        xs += np.cos(rI) * np.cos(rD)
        ys += np.cos(rI) * np.sin(rD)
        zs += np.sin(rI)  # because all vectors have a length of 1
    # xyzDIR
    Rs = np.sqrt(xs**2 + ys**2 + zs **2)
    Dm = np.degrees(np.arccos(xs / np.sqrt(xs**2 + ys**2)))
    if ys < 0: Dm = -Dm
    dr = Dm - 360 * int(Dm / 360)
    if dr < 0: dr += 360
    Dm = dr
    Im = np.degrees(np.arcsin(zs / Rs))
    # normalized x, y, z
    xm = xs/Rs
    ym = xs/Rs
    zm = xs/Rs
    # because of all vectors is have the length of 1, ipar <= 1 is True and then:
    Rm = Rs / n  # normalized length of the average vector
    k = (n - 1) / (n - Rs)
    if k < 4:
        if Rm <= 0.001:
            k = 3 * Rm
            a95 = 180
            return a95, k, Rs, Dm, Im, xs, ys, zs
        k = 20
        while True:
            cth = (1 + np.exp(-2 * k) / (1 - np.exp(-2 * k)))
            k1 = 1 / (cth - Rm)
            if abs(k - k1) <= 0.01:
                k = k1
                break
            k = k1
        a95 = np.degrees(np.arccos(1 + np.log(1 - 0.95 * (1 - np.exp(-2 * k))) / k))
        return a95, k, Rs, Dm, Im, xs, ys, zs
    a95 = np.degrees(np.arccos(1 - 2.9957 / (n * k)))
    return a95, k, Rs, Dm, Im, xs, ys, zs


def give_principal_components(data, full_data, selected_dots):
    # data centering
    m = np.array([data[:,0].mean(), data[:,1].mean()])
    data_centered = data - m
    # sklearn pca
    model = PCA(n_components=2)
    model.fit(data_centered)
    w_pca = model.components_
    pca_x = data_centered[:,0] + m[0]
    pca_y = -(w_pca[1,0]/w_pca[1,1])*data_centered[:,0] + m[1]
    # DIR part of PCA from Kirschvink 1980

    # matrix of sums of squares and products, Kirschvink 1980

    # xx_sum = 0
    # yy_sum = 0
    # zz_sum = 0
    # xy_sum = 0
    # xz_sum = 0
    # yz_sum = 0
    # for i in selected_dots:
    #     xx_sum += (full_data['X'][i]-np.average(full_data['X']))**2
    #     yy_sum += (full_data['Y'][i]-np.average(full_data['Y']))**2
    #     zz_sum += (full_data['Z'][i]-np.average(full_data['Z']))**2
    #     xy_sum += (full_data('X')[i]-np.average(full_data['X']))*(full_data['Y'][i]-np.average(full_data['Y']))
    #     xz_sum += (full_data['X'][i]-np.average(full_data['X']))*(full_data['Z'][i]-np.average(full_data['Z']))
    #     yz_sum += (full_data['Y'][i]-np.average(full_data['Y']))*(full_data['Z'][i]-np.average(full_data['Z']))

    return (
        pca_x,
        pca_y
    )


def kb_for_xy(x1, x2, y1, y2):
    k = (y1-y2)/(x1-x2)
    b = y1 - x1*k
    return k, b


def give_y_from_x(k, b, xs):
    y = []
    for x in xs:
        y.append(k*x+b)
    return y


def xy_solution(k1, b1, k2, b2):
    x = (b2-b1)/(k1-k2)
    y = k1*x + b1
    return x, y


def xyz_to_dir(x, y, z):
    Rs = np.sqrt(x * x + y * y + z * z)
    D = np.degrees(np.arccos(x / np.sqrt(x * x + y * y)))
    if y < 0:
        D = -D
    dr = D - 360 * int(D / 360)
    if dr < 0:
        dr += 360
    D = dr
    I = np.degrees(np.arcsin(z / Rs))
    return I, D


def dir_to_xyz(d, i, r):
    d = np.radians(d)
    i = np.radians(i)
    x = r * np.cos(i) * np.cos(d)
    y = r * np.cos(i) * np.sin(d)
    z = r * np.sin(i)
    return x, y, z


def intensity_to_specimen(X, Y, Z):
    X_spec = []
    Y_spec = []
    Z_spec = []

    for k in range(len(X)):
        x = X[k]
        y = Y[k]
        z = Z[k]

        intensity = np.sqrt(x**2 + y**2 + z**2)

        if x < 0:
            if np.degrees(np.arctan(y/x)) < 0:
                d = np.arctan(y/x) + 360
            else:
                d = np.arctan(y/x)
        else:
            if np.degrees(np.arctan(y/x)) + 180 < 0:
                d = np.arctan(y/x) + 180 + 360
            else:
                d = np.arctan(y/x) + 180

        i = np.arcsin(z/intensity)

        X_spec.append(np.cos(i) * np.cos(d))
        Y_spec.append(np.cos(i) * np.sin(d))
        Z_spec.append(np.sin(i))

    X_spec = np.array(X_spec)
    Y_spec = np.array(Y_spec)
    Z_spec = np.array(Z_spec)

    return X_spec, Y_spec, Z_spec


def xyz_to_xyz_geol(x, y, z, a, b):
    sin_a = np.sin(np.radians(a))
    sin_b = np.sin(np.radians(b))
    cos_a = np.cos(np.radians(a))
    cos_b = np.cos(np.radians(b))
    x_geol = x*cos_a*cos_b - y*sin_a - z*cos_a*sin_b
    y_geol = x*sin_a*cos_b + y*cos_a - z*sin_a*sin_b
    z_geol = x*sin_b + z*cos_b
    return x_geol, y_geol, z_geol


def xyz_geol_to_xyz_strat(x, y, z, s, d):
    sin_s = np.sin(np.radians(s))
    sin_d = np.sin(np.radians(d))
    cos_s = np.cos(np.radians(s))
    cos_d = np.cos(np.radians(d))
    tmp_x = x*cos_s*cos_d + y*sin_s*cos_d + z*sin_d
    tmp_y = -x*sin_s + y*cos_s
    x_strat = tmp_x*cos_s - tmp_y*sin_s
    y_strat = tmp_x*sin_s - tmp_y*cos_s
    z_strat = -x*cos_s*sin_d - y*sin_s*sin_d + z*cos_d
    return x_strat, y_strat, z_strat


def graph_data_elem(x, y, mode, size, symbol, color, opacity, text, text_position):
    if mode == "markers":
        return(
            go.Scatter(
                x=x,
                y=y,
                mode=mode,
                marker=dict(
                    color=color,
                    size=size,
                    symbol=symbol,
                    opacity=opacity
                )
            )
        )
    if mode == "lines":
        return(
            go.Scatter(
                x=x,
                y=y,
                mode=mode,
                line=dict(
                    color=color,
                    width=1,
                )
            )
        )
    if mode == "lines+markers":
        return(
            go.Scatter(
                x=x,
                y=y,
                mode=mode,
                marker=dict(
                    color=color[0],
                    size=size,
                    line=dict(
                        color=color[1],
                        width=1
                    ),
                    symbol=symbol
                ),
                line=dict(
                    color=color[2],
                    width=1
                )
            ),
        )
    if mode == "text":
        return(
            go.Scatter(
                x=x,
                y=y,
                mode=mode,
                text=text,
                textposition=text_position,
                textfont=dict(
                    family='Times New Roman',
                    size=20,
                    color=color
                )
            )
        )


tab_selected_style = {
    'borderTop': '1px solid #d6d6d6',
    'borderBottom': '1px solid #d6d6d6',
    'backgroundColor': 'rgba(17, 157, 255, .50)',
    'color': 'white',
    'padding': '6px'
}
radio_tab_style = {
    'backgroundColor': 'white',
    'padding': '6px'
}

layout = [
    html.Div(
        [
            html.Div(
                className="card",
                children=[
                    dcc.Upload(
                        id='upload-data',
                        className="upload-container",
                        children=[
                            html.Div(
                                children=[
                                    html.A('Select'),
                                    ' or drop file (only .PMD)'
                                ]
                            ),
                        ],
                        multiple=False
                    ),
                ]
            ),

            html.Div(
                className="card file-info centering",
                children=[
                    html.Details(
                        className="pretty-spoiler-big",
                        open=True,
                        children=[
                            html.Summary(
                                id="filename"
                            ),
                            html.Div(
                                className="row file-info centering",
                                id="file-info",
                                children=[
                                    html.Div(
                                        className="four columns card",
                                        children=[
                                            html.Div(
                                                className="bg-white user-control",
                                                children=[
                                                    dcc.Tabs(
                                                        id='system',
                                                        value="geographic",
                                                        children=[
                                                            dcc.Tab(
                                                                label="geographic",
                                                                value="geographic",
                                                                className="radio-tab",
                                                                style=radio_tab_style,
                                                                selected_style=tab_selected_style
                                                            ),
                                                            dcc.Tab(
                                                                label="stratigraphic",
                                                                value="stratigraphic",
                                                                className="radio-tab",
                                                                style=radio_tab_style,
                                                                selected_style=tab_selected_style
                                                            )
                                                        ]
                                                    ),
                                                    html.Div(
                                                        className="row padding-top-bot",
                                                        children=[
                                                            html.Div(
                                                                className="nine columns",
                                                                children=[
                                                                    html.Abbr(
                                                                        className="pretty-abbr",
                                                                        title="Automatically creating pdf copy of chart after downloading this chart.",
                                                                        children=[
                                                                            dcc.Markdown(
                                                                                className="pretty-markdown-left",
                                                                                children=[
                                                                                    "**Auto-PDF**"
                                                                                ]
                                                                            )
                                                                        ]
                                                                    ),

                                                                ],
                                                                style={
                                                                    "padding-top":"6px",
                                                                }
                                                            ),
                                                            html.Div(
                                                                className="three columns",
                                                                children=[
                                                                    daq.BooleanSwitch(
                                                                        id="pdf-copy",
                                                                        on=True,
                                                                    ),
                                                                ],
                                                                style={
                                                                    "padding-top":"6px",
                                                                }
                                                            ),
                                                            dcc.Markdown(
                                                                id="pdf-copy-output",
                                                            )
                                                        ]
                                                    ),
                                                    html.Div(
                                                        className="row padding-top-bot",
                                                        children=[
                                                            html.Div(
                                                                className="nine columns",
                                                                children=[
                                                                    html.Abbr(
                                                                        className="pretty-abbr",
                                                                        title="Automatically creating multi-plot of 3 plots below.",
                                                                        children=[
                                                                            dcc.Markdown(
                                                                                className="pretty-markdown-left",
                                                                                children=[
                                                                                    "**Multi-plot**"
                                                                                ]
                                                                            )
                                                                        ]
                                                                    ),

                                                                ],
                                                                style={
                                                                    "padding-top":"6px",
                                                                }
                                                            ),
                                                            html.Div(
                                                                className="three columns",
                                                                children=[
                                                                    daq.BooleanSwitch(
                                                                        id="multi-plot",
                                                                        on=True,
                                                                    ),
                                                                ],
                                                                style={
                                                                    "padding-top":"6px",
                                                                }
                                                            )
                                                        ]
                                                    ),
                                                    html.Div(
                                                        className="row padding-top-bot",
                                                        children=[
                                                            html.Div(
                                                                className="four columns centering",
                                                                children=[
                                                                    dcc.Markdown(
                                                                        className="pretty-markdown-left",
                                                                        children=[
                                                                            "**Dots**"
                                                                        ]
                                                                    ),
                                                                ],
                                                                style={
                                                                    "padding-top":"6px",
                                                                }
                                                            ),
                                                            html.Div(
                                                                className="four columns",
                                                                children=[
                                                                    daq.NumericInput(
                                                                        id='dots-size',
                                                                        className="pretty-numeric-input",
                                                                        min=1,
                                                                        max=12,
                                                                        value=8,
                                                                        size=100,
                                                                    )
                                                                ],
                                                                style={
                                                                    "align":"center",
                                                                }
                                                            ),
                                                            html.Div(
                                                                className="four columns",
                                                                children=[
                                                                    dcc.Dropdown(
                                                                        className="pretty-dropdown",
                                                                        id='marker-symbol',
                                                                        options=[
                                                                            {'label': 'Circle', 'value': 'circle'},
                                                                            {'label': 'Square', 'value': 'square'},
                                                                            {'label': 'Triangle', 'value': 'triangle-up'},
                                                                            {'label': 'Star', 'value': 'star'}
                                                                        ],
                                                                        value='circle'
                                                                    )
                                                                ],
                                                                style={
                                                                    "padding-top":"1.4px",
                                                                }
                                                            )
                                                        ]
                                                    ),
                                                ]
                                            )
                                        ]
                                    ),
                                    html.Div(
                                        className="eight columns card",
                                        children=[
                                            html.Div(
                                                className="bg-white pretty-table",
                                                id='datatable-pmd',
                                                children=[
                                                    dash_table.DataTable(
                                                        id="data-pmd",
                                                        data=dff.to_dict('records'),
                                                        columns=[{'name': i, 'id': i} for i in dff.columns],
                                                        style_header={
                                                            'backgroundColor': '#F5FFFA',
                                                            'fontWeight': 'bold',
                                                        },
                                                        style_table={
                                                            'maxHeight': '200px',
                                                            'overflowY': 'scroll',
                                                        }
                                                    )
                                                ]
                                            )
                                        ],
                                    )
                                ]
                            )
                        ]
                    )
                ]
            ),

            html.Div(
                className="row user-controls",
                children=[
                    html.Div(
                        className="four columns card",
                        children=[
                            html.Details(
                                className="pretty-spoiler",
                                open=True,
                                children=[
                                    html.Summary("Chart settings"),
                                    html.Div(
                                        className="bg-white user-control",
                                        children=[
                                            dcc.Tabs(
                                                id='system',
                                                value="geographic",
                                                children=[
                                                    dcc.Tab(
                                                        label="geographic",
                                                        value="geographic",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    ),
                                                    dcc.Tab(
                                                        label="stratigraphic",
                                                        value="stratigraphic",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    )
                                                ]
                                            ),
                                            dcc.Tabs(
                                                className="padding-top-bot",
                                                id='line-mode',
                                                value="orthodromy",
                                                children=[
                                                    dcc.Tab(
                                                        label="straight lines",
                                                        value="straight",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    ),
                                                    dcc.Tab(
                                                        label="orthodromen",
                                                        value="orthodromy",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    ),
                                                    dcc.Tab(
                                                        label="without lines",
                                                        value="nothing",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    )
                                                ]
                                            ),
                                            html.Div(
                                                className="padding-top-bot",
                                                children=[
                                                    html.H4("Annotations"),

                                                    dcc.Dropdown(
                                                        id='dots-with-annotation',
                                                        multi=True,
                                                        value=None,
                                                        style={
                                                            'margin-top': '5px',
                                                        },
                                                    ),
                                                ]
                                            ),
                                            html.Div(
                                                className="padding-top-bot",
                                                children=[
                                                    dcc.Dropdown(
                                                        id='text-position-polar',
                                                        options=[
                                                            {'label': 'Top left', 'value': 'top left'},
                                                            {'label': 'Top center', 'value': 'top center'},
                                                            {'label': 'Top right', 'value': 'top right'},
                                                            {'label': 'Middle left', 'value': 'middle left'},
                                                            {'label': 'Middle', 'value': 'middle center'},
                                                            {'label': 'Middle right', 'value': 'middle right'},
                                                            {'label': 'Bottom left', 'value': 'bottom left'},
                                                            {'label': 'Bottom center', 'value': 'bottom center'},
                                                            {'label': 'Bottom right', 'value': 'bottom right'}
                                                        ],
                                                        value='top left',
                                                        style={
                                                            # 'width': '100%',
                                                            'margin-top': '5px',
                                                        },
                                                    ),
                                                ],
                                            ),
                                        ],
                                    )
                                ]
                            )
                        ],
                    ),
                    html.Div(
                        className="four columns card",
                        children=[
                            html.Details(
                                className="pretty-spoiler",
                                open=True,
                                children=[
                                    html.Summary("Chart settings"),
                                    html.Div(
                                        className="bg-white user-control",
                                        children=[
                                            html.Div(
                                                className="padding-top-bot",
                                                children=[
                                                    html.H4("Annotations"),

                                                    dcc.Dropdown(
                                                        id='text-position-mag',
                                                        options=[
                                                            {'label': 'Top left', 'value': 'top left'},
                                                            {'label': 'Top center', 'value': 'top center'},
                                                            {'label': 'Top right', 'value': 'top right'},
                                                            {'label': 'Middle left', 'value': 'middle left'},
                                                            {'label': 'Middle', 'value': 'middle center'},
                                                            {'label': 'Middle right', 'value': 'middle right'},
                                                            {'label': 'Bottom left', 'value': 'bottom left'},
                                                            {'label': 'Bottom center', 'value': 'bottom center'},
                                                            {'label': 'Bottom right', 'value': 'bottom right'}
                                                        ],
                                                        value='bottom right',
                                                        style={
                                                            # 'width': '100%',
                                                            'margin-top': '5px',
                                                        },
                                                    ),
                                                ],
                                            )
                                        ],
                                    )
                                ]
                            )
                        ],
                    ),
                    html.Div(
                        className="four columns card",
                        children=[
                            html.Details(
                                className="pretty-spoiler",
                                open=True,
                                children=[
                                    html.Summary("Chart settings"),
                                    html.Div(
                                        className="bg-white user-control",
                                        children=[
                                            dcc.Tabs(
                                                id='system-zyid',
                                                value="core",
                                                children=[
                                                    dcc.Tab(
                                                        label="core",
                                                        value="core",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    ),
                                                    dcc.Tab(
                                                        label="geographic",
                                                        value="geographic",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    ),
                                                    dcc.Tab(
                                                        label="stratigraphic",
                                                        value="stratigraphic",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    )
                                                ]
                                            ),
                                            dcc.Tabs(
                                                className="padding-top-bot",
                                                id='xyz-position',
                                                value="NN",
                                                children=[
                                                    dcc.Tab(
                                                        label="N,N / E,UP",
                                                        value="NN",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    ),
                                                    dcc.Tab(
                                                        label="N,UP / E,E",
                                                        value="NUP",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    ),
                                                    dcc.Tab(
                                                        label="W,UP / N,N",
                                                        value="WUP",
                                                        className="radio-tab",
                                                        style=radio_tab_style,
                                                        selected_style=tab_selected_style
                                                    )
                                                ]
                                            ),
                                            html.Details(
                                                className="padding-top-bot bg-white",
                                                open=False,
                                                children = [
                                                    html.Summary("PCA"),
                                                    dcc.Tabs(
                                                        className="padding-top-bot",
                                                        id='approx-mode',
                                                        value='nonzero-mode',
                                                        children=[
                                                            dcc.Tab(
                                                                label="standard-mode",
                                                                value="nonzero-mode",
                                                                className="radio-tab",
                                                                style=radio_tab_style,
                                                                selected_style=tab_selected_style
                                                            ),
                                                            dcc.Tab(
                                                                label="zero-mode",
                                                                value="zero-mode",
                                                                className="radio-tab",
                                                                style=radio_tab_style,
                                                                selected_style=tab_selected_style,
                                                            ),
                                                        ]
                                                    ),
                                                    dcc.Dropdown(
                                                        id='dots-to-approx',
                                                        multi=True,
                                                        value=None,
                                                        style={
                                                            'margin-top': '5px',
                                                        },
                                                    ),
                                                    dcc.Markdown(
                                                        id='pca-data',
                                                        children='',
                                                        style={
                                                            "text-transform":"none",
                                                            "font-family": "Roboto",
                                                            "font-weight": "500",
                                                            "font-size": "16px",
                                                            "text-align": "center",
                                                            "border-bottom": "1px solid #C8D4E3",
                                                            "border-top": "1px solid #C8D4E3",
                                                            "padding-top": "6px",
                                                            "margin-top": "10px",
                                                            "margin-bottom": "10px"
                                                        }
                                                    ),
                                                    html.Div(
                                                        className="row",
                                                        children=[
                                                            html.Div(
                                                                className="six columns",
                                                                children=[
                                                                    html.Button(
                                                                        'Add to table',
                                                                        id='pca-button',
                                                                        className='choose-button',
                                                                        style={
                                                                            'margin-bottom': '10px'
                                                                        },
                                                                        n_clicks=0
                                                                    ),
                                                                ]
                                                            ),
                                                            html.Div(
                                                                className="six columns",
                                                                children=[
                                                                    dcc.Input(id="pca-filename", type="text", placeholder="Filename"),
                                                                ]
                                                            )
                                                        ]
                                                    ),
                                                    dash_table.DataTable(
                                                        id="pca-output-table",
                                                        columns=[{"name": "Steprange", "id": "Steprange"}, {"name": "N", "id": "N"},
                                                                 {"name": "Dg", "id": "Dg"}, {"name": "Ig", "id": "Ig"},
                                                                 {"name": "kg", "id": "kg"}, {"name": "a95g", "id": "a95g"},
                                                                 {"name": "Ds", "id": "Ds"}, {"name": "Is", "id": "Is"},
                                                                 {"name": "ks", "id": "ks"}, {"name": "a95s", "id": "a95s"},
                                                                 ],
                                                        data=[],
                                                        style_header={
                                                            'backgroundColor': '#F5FFFA',
                                                            'fontWeight': 'bold',
                                                        },
                                                        style_table={
                                                            'maxHeight': '200px',
                                                            'overflowY': 'scroll',
                                                        },
                                                        editable=True,
                                                        row_deletable=True,
                                                    ),
                                                    html.A(
                                                        'Download data',
                                                        id='download-pca',
                                                        className="margin__rows",
                                                        target="_blank",
                                                    )
                                                ]
                                            ),

                                            html.Div(
                                                className="padding-top-bot",
                                                children=[
                                                    html.H4("Annotations"),

                                                    dcc.Dropdown(
                                                        id='text-position-xyz',
                                                        options=[
                                                            {'label': 'Top left', 'value': 'top left'},
                                                            {'label': 'Top center', 'value': 'top center'},
                                                            {'label': 'Top right', 'value': 'top right'},
                                                            {'label': 'Middle left', 'value': 'middle left'},
                                                            {'label': 'Middle', 'value': 'middle center'},
                                                            {'label': 'Middle right', 'value': 'middle right'},
                                                            {'label': 'Bottom left', 'value': 'bottom left'},
                                                            {'label': 'Bottom center', 'value': 'bottom center'},
                                                            {'label': 'Bottom right', 'value': 'bottom right'}
                                                        ],
                                                        value='bottom right',
                                                        style={
                                                            'margin-top': '5px',
                                                        },
                                                    ),
                                                ],
                                            ),
                                        ],
                                    )
                                ]
                            )
                        ],
                    ),
                ]
            ),

            html.Div(
                className="row charts padding-center",
                children=[
                    html.Div(
                        className="four columns card",
                        children=[
                            html.Div(
                                className="bg-white chart",
                                children=[
                                    dcc.Graph(
                                        id='polar-scatter-pm',
                                        config={
                                            'toImageButtonOptions': {
                                                'format': 'svg'
                                            },
                                            'modeBarButtonsToRemove': [
                                                "zoom2d"
                                            ],
                                            'showLink': True,
                                            'displaylogo': False,
                                            'scrollZoom': True,
                                            'displayModeBar': True,
                                            'edits': {
                                                'annotationPosition': True,
                                                'annotationText': True,
                                                'annotationTail': True
                                            },
                                        },
                                    ),
                                ]
                            ),
                        ],
                    ),
                    html.Div(
                        className="four columns card",
                        children=[
                            html.Div(
                                className="bg-white chart",
                                children=[
                                    dcc.Graph(
                                        id='MAG-scatter-pm',
                                        config={
                                            'toImageButtonOptions': {
                                                'format': 'svg',
                                            },
                                            'showLink': True,
                                            'displaylogo': False,
                                            'scrollZoom': True,
                                            'displayModeBar': True,
                                            'edits': {
                                                'annotationPosition': True,
                                                'annotationText': True,
                                                'annotationTail': True
                                            },
                                        },

                                    )
                                ]
                            ),
                        ],
                    ),
                    html.Div(
                        className="four columns card",
                        children=[
                            html.Div(
                                className="bg-white chart",
                                children=[
                                    dcc.Graph(
                                        id='xyz-scatter-pm',
                                        config={
                                            'toImageButtonOptions': {
                                                'format': 'svg',
                                            },
                                            'showLink': True,
                                            'displaylogo': False,
                                            'scrollZoom': True,
                                            'displayModeBar': True,
                                            'edits': {
                                                'annotationPosition': True,
                                                'annotationText': True,
                                                'annotationTail': True
                                            },
                                        },
                                    )
                                ]
                            ),
                        ],
                    ),
                ]
            ),

            html.Div(
                className="charts padding-center",
                children=[
                    html.Div(
                        className="card",
                        children=[
                            html.Div(
                                className="bg-white chart",
                                id='allCharts-scatter-pmd',
                                children=[

                                ]
                            ),
                        ]
                    )
                ]
            )
        ],
    )
]

@app.callback(
    dash.dependencies.Output("filename", "children"),
    [dash.dependencies.Input("upload-data", "filename")]
)
def fileinfo_spoiler(filename):
    if filename:
        return filename
    return "Example.pmd"


@app.callback(
    dash.dependencies.Output('pdf-copy-output', ''),
    [dash.dependencies.Input('pdf-copy', 'on')]
)
def create_pdf_copy(create_copy):
    if create_copy:
        home = Path.home()
        downloads = home / 'Downloads'

        while 1:
            database = open('last_number', 'r')
            database_svg_file = database.read()
            database.close()

            Home = os.path.expanduser('~')
            downloads_path = os.path.join(Home, "Downloads/*.svg")
            list_of_files = glob.glob(downloads_path)  # * means all, if need specific format then *.csv
            latest_svg_file = max(list_of_files, key=os.path.getctime)

            if not database_svg_file:
                database = open('last_number', 'w')
                database.write("tmp_svg_file")
                database.close()

            if latest_svg_file != database_svg_file:
                pdf_file = latest_svg_file[:-3]+"pdf"

                data = cairosvg.svg2pdf(url=latest_svg_file, write_to=pdf_file)

                database = open('last_number', 'w')
                database.write(latest_svg_file)
                database.close()

            time.sleep(1)


@app.callback(
    dash.dependencies.Output('datatable-pmd', 'children'),
    [dash.dependencies.Input('upload-data', 'contents')],
    [dash.dependencies.State('upload-data', 'filename')]
)
def update_output_datatable(list_of_contents, name):
        if list_of_contents is not None:
            children = [parse_contents_for_plot_dt(list_of_contents, name, "for_table")]
            return children
        else:
            df = pd.DataFrame(
                {'T or M': [], 'X': [], 'Y': [], 'Z': [], 'MAG': [], 'Dg': [], 'Ig': [], 'Ds': [], 'Is': [], 'a95': []})
            return html.Div(
                className="pretty-table",
                children=[
                    dash_table.DataTable(
                        id='data-pmd',
                        data=df.to_dict('records'),
                        columns=[{'name': i, 'id': i} for i in df.columns],
                        style_header={
                            'backgroundColor': '#F5FFFA',
                            'fontWeight': 'bold',
                        },
                        style_table={
                            'maxHeight': '300px',
                            'overflowY': 'scroll',
                        }
                    )
                ]
            )


@app.callback(
    dash.dependencies.Output('polar-scatter-pm', 'figure'),
    [dash.dependencies.Input('system', 'value'),
     dash.dependencies.Input('dots-size', 'value'),
     dash.dependencies.Input('marker-symbol', 'value'),
     dash.dependencies.Input('text-position-polar', 'value'),
     dash.dependencies.Input('data-pmd', 'data'),
     dash.dependencies.Input('dots-with-annotation', 'value'),
     dash.dependencies.Input('line-mode', 'value')]
)
def update_graph_polar_pm(system, dots_size, marker_symbol,
                          text_position, data, dots_with_annotation,
                          line_mode):
    df = pd.DataFrame(data)

    for i in df.columns:
        df[i] = pd.to_numeric(df[i])

    axdots_r = []
    axdots_a = []
    for i in [0, 90, 180, 270]:
        for j in range(10, 90, 10):
            axdots_r.append(j)
            axdots_a.append(i)

    if df.empty:
        df = pd.DataFrame(
            {'T/M': [], 'X': [], 'Y': [], 'Z': [], 'MAG': [], 'Dg': [], 'Ig': [], 'Ds': [], 'Is': [],
             'a95': []})
        return {
            'data': [
                go.Scatterpolar(
                    r=axdots_r,
                    theta=axdots_a,
                    mode="markers",
                    marker=dict(
                        color='black',
                        size=2
                    )
                ),
                go.Scatterpolar(
                    r=[0],
                    theta=[0],
                    mode="markers",
                    marker=dict(
                        color='black',
                        size=7,
                        symbol="cross-thin-open"
                    )
                )
            ],
            'layout': go.Layout(
                font=dict(
                    family="Times New Roman",
                    size=25,
                    color="black"
                ),
                showlegend=False,
                polar=dict(
                    angularaxis=dict(
                        tickfont=dict(
                            size=25,
                            family="Times New Roman"
                        ),
                        rotation=90,
                        direction="clockwise",
                        dtick=90,
                        tickmode="array",
                        tickvals=[0, 90, 180, 270],
                        ticktext=["N", "E", "S", "W"],
                        ticksuffix=0,
                        showgrid=False
                    ),
                    radialaxis=dict(
                        range=[0, 90],
                        visible=False
                    )
                )
            )
        }

    col_D = "Dg"
    col_I = "Ig"

    if system == "stratigraphic":
        col_D = "Ds"
        col_I = "Is"

    angles_neg = []
    angles_pos = []
    values_neg = []
    values_pos = []
    values_abs = []
    angles_abs = list(abs(df[col_D]))

    for i in range(0, len(df[col_I]), 1):
        if df[col_I][i] < 0:
            values_neg.append(abs(df[col_I][i]+90))
            values_abs.append(abs(df[col_I][i]+90))
            angles_neg.append(df[col_D][i])
        else:
            values_pos.append(abs(df[col_I][i]-90))
            values_abs.append(abs(df[col_I][i]-90))
            angles_pos.append(df[col_D][i])

    unit = u"\u00B0"
    first_col_name = 'T'

    if 'M' in data[0]:
        first_col_name = 'M'
        unit = "mT"

    dots_with_annotation_r = list()
    dots_with_annotation_t = list()
    dots_with_annotation_u = list()

    if dots_with_annotation:
        for i in dots_with_annotation:
            dots_with_annotation_r.append(abs(abs(df[col_I][i]) - 90))
            dots_with_annotation_t.append(df[col_D][i])
            dots_with_annotation_u.append(str(int(df[first_col_name][i])) + unit)

    orthodromen_D, orthodromen_I = create_orthodromy(df, system)
    orthodromen = []
    for i in range(len(orthodromen_D)):
        orthodromy = go.Scatterpolar(
            r=orthodromen_I[i],
            theta=orthodromen_D[i],
            mode='lines',
            line=dict(
                color="black",
                width=1
            )
        )
        orthodromen.append(orthodromy)

    graph_data = [
        # graph structure
        go.Scatterpolar(
            r=axdots_r,
            theta=axdots_a,
            mode="markers",
            marker=dict(
                color='black',
                size=2
            )
        ),
        go.Scatterpolar(
            r=[0],
            theta=[0],
            mode="markers",
            marker=dict(
                color='black',
                size=7,
                symbol="cross-thin-open"
            )
        ),
        # text of first and last dots
        go.Scatterpolar(
            r=dots_with_annotation_r,
            theta=dots_with_annotation_t,
            mode="text",
            text=dots_with_annotation_u,
            textposition=text_position,
            textfont=dict(
                family='Times New Roman',
                size=20,
                color='black'
            )
        )
        # lines
    ]

    if line_mode == "straight":
        graph_data.append(
            go.Scatterpolar(
                r=values_abs,
                theta=angles_abs,
                mode='lines',
                line=dict(
                    color='black',
                    width=1
                )
            )
        )
    elif line_mode == "orthodromy":
        for orthodromy in orthodromen:
            graph_data.append(orthodromy)

    graph_data.append(
        # dots
        go.Scatterpolar(
            r=values_pos,
            theta=angles_pos,
            mode="markers",
            marker=dict(
                color='black',
                size=dots_size,
                symbol=marker_symbol
            ),
        )
    )
    graph_data.append(
        go.Scatterpolar(
            r=values_neg,
            theta=angles_neg,
            mode="markers",
            marker=dict(
                color='white',
                size=dots_size,
                symbol=marker_symbol,
                line=dict(
                    color='black',
                    width=1
                )
            )
        )
    )

    return {
        'data': graph_data,
        'layout': go.Layout(
            font=dict(
                family="Times New Roman",
                size=25,
                color="black"
            ),
            showlegend=False,
            polar=dict(
                angularaxis=dict(
                    tickfont=dict(
                        size=25,
                        family="Times New Roman"
                    ),
                    rotation=90,
                    direction="clockwise",
                    dtick=90,
                    tickmode="array",
                    tickvals=[0, 90, 180, 270],
                    ticktext=["N", "E", "S", "W"],
                    ticksuffix=0,
                    showgrid=False
                ),
                radialaxis=dict(
                    range=[0, 90],
                    visible=False
                )
            ),
        )
    }

@app.callback(
    dash.dependencies.Output('MAG-scatter-pm', 'figure'),
    [dash.dependencies.Input('dots-size', 'value'),
     dash.dependencies.Input('marker-symbol', 'value'),
     dash.dependencies.Input('data-pmd', 'data'),
     dash.dependencies.Input('text-position-mag', 'value'),
     dash.dependencies.Input('dots-with-annotation', 'value'),
     ]
)
def update_graph_intensity(dots_size, marker_symbol, data, text_position, dots_with_annotation):
    df = pd.DataFrame(data)

    for i in df.columns:
        df[i] = pd.to_numeric(df[i])

    relative_mag = []
    first_col = []

    if df.empty:
        return {
            'data': [
                go.Scatter(
                    x=first_col,
                    y=relative_mag,
                    mode='lines',
                )
            ],
            'layout': go.Layout(
                font=dict(
                    family="Times New Roman",
                    size=25,
                    color="black"
                ),
                showlegend=False,
                grid=dict(
                    xside='bottom plot',
                    yside='left',
                ),
                xaxis=dict(
                    showgrid=False,
                    zeroline=False,
                    showticklabels=False,
                    showline=True,
                    linewidth=1.5,
                    anchor='free',
                    rangemode='tozero'
                ),
                yaxis=dict(
                    showgrid=False,
                    zeroline=False,
                    showticklabels=False,
                    showline=True,
                    linewidth=1.5,
                    anchor='free',
                    rangemode='tozero'
                ),
            )
        }

    for mag in df.MAG:
        relative_mag.append(mag / max(df.MAG))

    unit = u'\u2103'
    first_col_name = "T"
    x_title_space = 1.1

    if "M" in data[0]:
        first_col_name = "M"
        unit = "mT"
        x_title_space = 1.15

    for i in df[first_col_name]:
        first_col.append(i)

    # check for content in file

    # raw_annotations = open("mag_annotations.txt", "r", encoding='utf-16').read().split('|')
    end_annotations = [
        go.layout.Annotation(
            x=x_title_space,
            y=-0.05,
            showarrow=False,
            text=unit,
            xref="paper",
            yref="paper"
        ),
        go.layout.Annotation(
            x=-0.1,
            y=1.15,
            showarrow=False,
            text='M/M' + u'\u2098' + u'\u2090' + u'\u2093' + '|M' + u'\u2098' + u'\u2090' + u'\u2093' +
                      ' = ' + str(format(max(df.MAG), '.2E')) + ' A/m',
            xref="paper",
            yref="paper"
        )
    ]
    # print(raw_annotations)
    # if raw_annotations and raw_annotations!=['']:
    #     for i in range(len(raw_annotations) - 1):
    #         annotation = {}
    #         for line in raw_annotations[i].split("\n")[0:-2]:
    #             key, value = line.split()
    #             if key == 'x' or key == '':
    #                 annotation[key] = float(value)
    #             elif key == 'visible' or key == 'showarrow':
    #                 annotation[key] = bool(value)
    #             else:
    #                 annotation[key] = value
    #         annotation['font'] = {'family': 'Times New Roman', 'size': 20, 'color': 'black'}
    #         end_annotations.append(annotation)
    # else:

    dots_with_annotation_x = list()
    dots_with_annotation_y = list()
    dots_with_annotation_u = list()

    if dots_with_annotation:
        for i in dots_with_annotation:
            dots_with_annotation_x.append(first_col[i])
            dots_with_annotation_y.append(relative_mag[i])
            dots_with_annotation_u.append(str(first_col[i]) + unit)

    # with open('mag_annotations.txt', 'w', encoding='utf-16') as file:
    #     for annotation in end_annotations:
    #         for key, value in annotation.items():
    #             file.write(f'{key} {value}\n')
    #         file.write('|')
    #
    # print(end_annotations)

    tick_values = [0, max(first_col) / 2, max(first_col)]
    tick_text_x = [0, max(first_col) / 2, max(first_col)]
    if first_col_name == "T":
        tick_values = np.arange(0, max(first_col), 50)
        tick_text_x = []
        for i in range(0, len(tick_values)):
            if i%2 == 0:
                tick_text_x.append(tick_values[i])
            else:
                tick_text_x.append('')

    return {
        'data': [
            go.Scatter(
                x=first_col,
                y=relative_mag,
                mode='lines',
                line=dict(
                    color='black',
                    width=1
                )
            ),
            go.Scatter(
                x=first_col,
                y=relative_mag,
                mode="markers",
                marker=dict(
                    color='white',
                    size=dots_size,
                    line=dict(
                        color='black',
                        width=1
                    ),
                    symbol=marker_symbol
                )
            ),
            go.Scatter(
                x=dots_with_annotation_x,
                y=dots_with_annotation_y,
                mode="text",
                text=dots_with_annotation_u,
                textposition=text_position,
                textfont=dict(
                    family='Times New Roman',
                    size=20,
                    color='black'
                )
            )
        ],
        'layout': go.Layout(
            hovermode='closest',
            font=dict(
                family="Times New Roman",
                size=25,
                color="black"
            ),
            showlegend=False,
            xaxis=dict(
                showgrid=False,
                tickvals=tick_values,
                ticktext=tick_text_x,
                ticks='inside',
                ticklen=10,
                tickson='boundaries',
                showline=True,
                linewidth=1.5,
                anchor='free',
                rangemode='tozero'
            ),
            yaxis=dict(
                showgrid=False,
                tickvals=[0.5, 1],
                ticks='inside',
                ticklen=10,
                tickson='boundaries',
                showline=True,
                linewidth=1.5,
                anchor='free',
                rangemode='tozero',
            ),
            annotations=end_annotations
        )
    }


@app.callback(
    dash.dependencies.Output('xyz-scatter-pm', 'figure'),
    [dash.dependencies.Input('upload-data', 'contents'),
     dash.dependencies.Input('system-zyid', 'value'),
     dash.dependencies.Input('data-pmd', 'data'),
     dash.dependencies.Input('dots-size', 'value'),
     dash.dependencies.Input('marker-symbol', 'value'),
     dash.dependencies.Input('text-position-xyz', 'value'),
     dash.dependencies.Input('xyz-position', 'value'),
     dash.dependencies.Input('approx-mode', 'value'),
     dash.dependencies.Input('dots-to-approx', 'value'),
     dash.dependencies.Input('dots-with-annotation', 'value')
     ],
    [dash.dependencies.State('upload-data', 'filename')]
)
def update_graph_xyz(list_of_contents, system, data, dots_size, marker_symbol, text_position, orientation, approx_mode, approx_dots,
                     dots_with_annotation, name):
    
    df = pd.DataFrame(data)

    for i in df.columns:
        df[i] = pd.to_numeric(df[i])

    if df.empty:
        return {
            'data': [
                go.Scatter(
                    x=[0, 0],
                    y=[0, 0],
                    mode='lines'
                )
            ],
            'layout': go.Layout(
                font=dict(
                    family="Times New Roman",
                    size=25,
                    color="black"
                ),
                showlegend=False,
                xaxis=dict(showgrid=False,
                           showticklabels=False,
                           zerolinewidth=1.5,
                           zerolinecolor='black',
                           ),
                yaxis=dict(
                    showgrid=False,
                    showticklabels=False,
                    zerolinewidth=1.5,
                    zerolinecolor='black',
                )
            )
        }

    extra_data = parse_contents_for_plot_dt(list_of_contents, name, "for_extra_data")
    A = extra_data[0]
    B = extra_data[1]
    S = extra_data[2]
    D = extra_data[3]

    hor_x = []
    hor_y = []
    vert_x = []
    vert_y = []
    title_x = ''
    title_y = ''

    # if system == "core"

    X = df['X']
    Y = df['Y']
    Z = df['Z']
    if system == "core":
        X, Y, Z = intensity_to_specimen(X, Y, Z)

    if system == "geographic":
        # X, Y, Z = dir_to_xyz(df["Dg"], df["Ig"], 1)
        X, Y, Z = intensity_to_specimen(X, Y, Z)
        X, Y, Z = xyz_to_xyz_geol(X, Y, Z, A, B)


    if system == "stratigraphic":
        # X, Y, Z = dir_to_xyz(df["Ds"], df["Is"], 1)
        X, Y, Z = intensity_to_specimen(X, Y, Z)
        X, Y, Z = xyz_to_xyz_geol(X, Y, Z, A, B)
        X, Y, Z = xyz_geol_to_xyz_strat(X, Y, Z, S, D)

    if orientation == 'NN':
        hor_x = Y
        hor_y = X
        vert_x = -Z
        vert_y = X
        title_x = 'E,UP'
        title_y = 'N,N'
    if orientation == 'NUP':
        hor_x = Y
        hor_y = X
        vert_x = Y
        vert_y = -Z
        title_x = 'E,E'
        title_y = 'N,UP'
    if orientation == 'WUP':
        hor_x = X
        hor_y = -Y
        vert_x = X
        vert_y = -Z
        title_x = 'N,N'
        title_y = 'W,UP'


    unit = u"\u00B0"
    first_col_name = 'T'

    if 'M' in data[0]:
        first_col_name = 'M'
        unit = "mT"

    dots_with_annotation_x = list()
    dots_with_annotation_y = list()
    dots_with_annotation_u = list()

    if dots_with_annotation:
        for i in dots_with_annotation:
            dots_with_annotation_x.append(vert_x[i])
            dots_with_annotation_y.append(vert_y[i])
            dots_with_annotation_u.append(str(df[first_col_name][i]) + unit)
            dots_with_annotation_x.append(hor_x[i])
            dots_with_annotation_y.append(hor_y[i])
            dots_with_annotation_u.append(str(df[first_col_name][i]) + unit)

    graph_data = [
        graph_data_elem(hor_x, hor_y, "lines+markers",
                        dots_size, marker_symbol, ['white', 'black', 'black'], None, None, None)[0],
        graph_data_elem(vert_x, vert_y, "lines+markers",
                        dots_size, marker_symbol, ['black', 'black', 'black'], None, None, None)[0],
        graph_data_elem(dots_with_annotation_x, dots_with_annotation_y, "text",
                        None, None, 'black', None, dots_with_annotation_u, text_position)

    ]

    # selected_dots
    selected_dots = go.Scatter()

    # titles of axes
    annotation_titles = [
        go.layout.Annotation(
            x=1.25,
            y=0.5,
            showarrow=False,
            text=title_x,
            xref="paper",
            yref="paper"
        ),
        go.layout.Annotation(
            x=0.5,
            y=1.15,
            showarrow=False,
            text=title_y,
            xref="paper",
            yref="paper"
        )
    ]
    click_mode='event'

    # pca

    pca_hor_x = []
    pca_hor_y = []
    pca_vert_x = []
    pca_vert_y = []

    pca_res_hor_x = []
    pca_res_hor_y = []
    pca_res_vert_x = []
    pca_res_vert_y = []

    if approx_dots:
        for dot in approx_dots:
            pca_hor_x.append(hor_x[dot])
            pca_hor_y.append(hor_y[dot])
            pca_vert_x.append(vert_x[dot])
            pca_vert_y.append(vert_y[dot])

        if approx_mode == 'zero-mode':
            pca_hor_x.append(0)
            pca_hor_y.append(0)
            pca_vert_x.append(0)
            pca_vert_y.append(0)

        hor = []
        for i in range(len(pca_hor_x)):
            hor.append([pca_hor_x[i], pca_hor_y[i]])
        hor = np.array(hor)
        pca_res_hor_x, pca_res_hor_y = give_principal_components(hor, data, approx_dots)
        k_hor, b_hor = kb_for_xy(
            pca_res_hor_x[0],
            pca_res_hor_x[1],
            pca_res_hor_y[0],
            pca_res_hor_y[1],
        )
        extra_hor_x = [2 * hor_x[0], -2 * hor_x[0]]
        extra_hor_y = give_y_from_x(k_hor, b_hor, extra_hor_x)
        pca_res_hor_x = np.append(pca_res_hor_x, extra_hor_x)
        pca_res_hor_y = np.append(pca_res_hor_y, extra_hor_y)


        vert = []
        for i in range(len(pca_hor_x)):
            vert.append([pca_vert_x[i], pca_vert_y[i]])
        vert = np.array(vert)
        pca_res_vert_x, pca_res_vert_y = give_principal_components(vert, data, approx_dots)
        k_vert, b_vert = kb_for_xy(
            pca_res_vert_x[0],
            pca_res_vert_x[1],
            pca_res_vert_y[0],
            pca_res_vert_y[1],
        )
        extra_vert_x = [hor_x[0], -hor_y[0]]
        extra_vert_y = give_y_from_x(k_vert, b_vert, extra_vert_x)
        pca_res_vert_x = np.append(pca_res_vert_x, extra_vert_x)
        pca_res_vert_y = np.append(pca_res_vert_y, extra_vert_y)

        x_sol, y_sol = xy_solution(k_hor, b_hor, k_vert, b_vert)

        a95, k, Rs, Dm, Im, xm, ym, zm = give_a95_k_rm(df, approx_dots, system, approx_mode)

        graph_data.append(graph_data_elem(pca_hor_x, pca_hor_y, 'markers',
                                          dots_size+6, marker_symbol, '#119DFF', 0.5, None, None))
        graph_data.append(graph_data_elem(pca_vert_x, pca_vert_y, 'markers',
                                          dots_size+6, marker_symbol,'#9933FF', 0.5, None, None))
        graph_data.append(graph_data_elem(pca_res_hor_x, pca_res_hor_y, 'lines',
                                          None, None, '#119DFF', None, None, None))
        graph_data.append(graph_data_elem(pca_res_vert_x, pca_res_vert_y, 'lines',
                                          None, None, '#9933FF', None, None, None))
        graph_data.append(graph_data_elem([x_sol], [y_sol], "markers",
                                          dots_size, marker_symbol, '#119DFF', 1, None, None))

    return {
        'data': graph_data,
        'layout': go.Layout(
            font=dict(
                family="Times New Roman",
                size=25,
                color="black"
            ),
            showlegend=False,
            xaxis=dict(
                showgrid=False,
                showticklabels=False,
                zerolinewidth=1.5,
                zerolinecolor='black',
                zeroline=True,
                # scaleratio=1
            ),
            yaxis=dict(
                showgrid=False,
                showticklabels=False,
                zerolinewidth=1.5,
                zerolinecolor='black',
                zeroline=True,
                # scaleanchor="x",
                # scaleratio=1,
            ),
            annotations=annotation_titles,
            clickmode=click_mode
        )
    }


@app.callback(
    dash.dependencies.Output('allCharts-scatter-pmd', 'children'),
    [dash.dependencies.Input('multi-plot', 'on'),
     dash.dependencies.Input('polar-scatter-pm', 'figure'),
     dash.dependencies.Input('MAG-scatter-pm', 'figure'),
     dash.dependencies.Input('xyz-scatter-pm', 'figure'),
     ]
)
def update_multi_chart(create_multi_plot, polar_chart, intensity_chart, zyid_chart):
    if create_multi_plot:
        fig = make_subplots(rows=1, cols=3, specs=[[{'type': 'xy'}, {'type': 'polar'}, {'type': 'xy'}]],
                            print_grid=False, shared_yaxes=False, shared_xaxes=False)
        for data in polar_chart['data']:
            fig.append_trace(data, row=1, col=2)
        for data in intensity_chart['data']:
            fig.append_trace(data, row=1, col=1)
        for data in zyid_chart['data']:
            fig.append_trace(data, row=1, col=3)

        fig.update_xaxes(intensity_chart['layout']['xaxis'], row=1, col=1)
        fig.update_yaxes(intensity_chart['layout']['yaxis'], row=1, col=1)
        fig.update_xaxes(zyid_chart['layout']['xaxis'], row=1, col=3)
        fig.update_yaxes(zyid_chart['layout']['yaxis'], row=1, col=3)

        intensity_chart['layout']['annotations'][0]['x'] = 0.3
        intensity_chart['layout']['annotations'][1]['x'] = -0.02
        zyid_chart['layout']['annotations'][0]['x'] = 1.05
        zyid_chart['layout']['annotations'][1]['x'] = 0.9
        all_annotations = intensity_chart['layout']['annotations']+zyid_chart['layout']['annotations']

        fig.update_layout(template="none", annotations=all_annotations, width=1400)

        fig.update_layout(polar_chart['layout'])
        #fig.update_layout(intensity_chart['layout'])
        return (
            dcc.Graph(
                figure=fig,
                config={
                    'toImageButtonOptions': {
                        'format': 'svg'
                    },
                    'modeBarButtonsToRemove': [
                        "zoom2d"
                    ],
                    'showLink': True,
                    'displaylogo': False,
                    'scrollZoom': True,
                    'displayModeBar': True,
                    'edits': {
                        'annotationPosition': True,
                        'annotationText': True,
                        'annotationTail': True
                    },
                    'autosizable': True,
                    'showAxisDragHandles': True
                },
                style={
                    'width': '100%'
                }
            ),
        )
        #
        # return fig


@app.callback(
    dash.dependencies.Output('dots-to-approx', 'options'),
    [dash.dependencies.Input('data-pmd', 'data')]
)
def pca_dots_list(data):
    df = pd.DataFrame(data)
    if df.empty:
        return [{'label': '', 'value': 'None'}]
    labels = create_dots_list(data, "dots-to-approx")
    return labels


@app.callback(
    dash.dependencies.Output('dots-with-annotation', 'options'),
    [dash.dependencies.Input('data-pmd', 'data')]
)
def annot_dots_list(data):
        df = pd.DataFrame(data)
        if df.empty:
            return [{'label': '', 'value': 'None'}]
        labels = create_dots_list(data, 'dots-with-annotation')
        return labels


@app.callback(
    dash.dependencies.Output('pca-data', 'children'),
    [dash.dependencies.Input('data-pmd', 'data'),
     dash.dependencies.Input('system', 'value'),
     dash.dependencies.Input('approx-mode', 'value'),
     dash.dependencies.Input('dots-to-approx', 'value')]
)
def pca_data(data, system, approx_mode, approx_dots):
    if approx_dots and data:
        df = pd.DataFrame(data)
        for i in df.columns:
            df[i] = pd.to_numeric(df[i])
        a95, k, Rs, Dm, Im, x, y, z = give_a95_k_rm(df, approx_dots, system, approx_mode)
        if system == "stratigraphic":
            return (
                    "**Ds** = " + str(round(Dm, 1)) + ";"
                    "    **Is** = " + str(round(Im, 1)) + ";"
                    "    **Ks** = " + str(round(k, 1)) + ";"
                    "  **a95s** = " + str(round(a95, 1))
            )
        else:
            return (
                    "**Dg** = " + str(round(Dm, 1)) + ";"
                    "    **Ig** = " + str(round(Im, 1)) + ";"
                    "    **Kg** = " + str(round(k, 1)) + ";"
                    "  **a95g** = " + str(round(a95, 1))
            )
    return


@app.callback(
    dash.dependencies.Output('pca-output-table', 'data'),
    [dash.dependencies.Input('pca-button', 'n_clicks')],
    [dash.dependencies.State('data-pmd', 'data'),
     dash.dependencies.State('system', 'value'),
     dash.dependencies.State('approx-mode', 'value'),
     dash.dependencies.State('dots-to-approx', 'value'),
     dash.dependencies.State('pca-output-table', 'data'),
     dash.dependencies.State('pca-output-table', 'columns')]
)
def pca_output_table(n_clicks, data, system, approx_mode, approx_dots, rows, columns):
    if approx_dots and data:
        df = pd.DataFrame(data)

        for i in df.columns:
            df[i] = pd.to_numeric(df[i])

        fcn = "T" # first column name
        if "M" in data[0]:
            fcn = "M"

        a95g, kg, Rg, Dg, Ig, xg, yg, zg = give_a95_k_rm(df, approx_dots, "Geographic", approx_mode)
        a95s, ks, Rs, Ds, Is, xs, ys, zs = give_a95_k_rm(df, approx_dots, "Stratigraphic", approx_mode)
        new_data = [fcn+str(df[fcn][min(approx_dots)])+"-"+fcn+str(df[fcn][max(approx_dots)]), len(approx_dots)+1,
                    round(Dg, 1), round(Ig, 1), round(kg, 1), round(a95g, 1),
                    round(Ds, 1), round(Is, 1), round(ks, 1), round(a95s, 1)]
        if n_clicks > 0:
            rows.append({col['id']: new_data[i] for i, col in enumerate(columns)})
    return rows

@app.callback(
    [dash.dependencies.Output('download-pca', 'href'),
    dash.dependencies.Output('download-pca', 'download')],
    [dash.dependencies.Input('pca-output-table', 'data'),
    dash.dependencies.Input('pca-filename', 'value')]
)
def download_pca(data, filename):
    if data and filename:
        pca_output = pd.DataFrame(data=data)
        csv_string = pca_output.to_csv(index=False, encoding='utf-8')
        csv_string = "data:text/csv;charset=utf-8," + parse.quote(csv_string)
        return (csv_string, filename+'.csv')

